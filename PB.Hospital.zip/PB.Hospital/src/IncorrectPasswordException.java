class IncorrectPasswordException extends Exception{
    public IncorrectPasswordException(String e){
        super(e);
    }

}